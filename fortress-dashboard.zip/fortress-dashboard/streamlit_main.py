import dashboard_compile

# Main dashboard compilation
def main():
    dashboard_compile.compile()

if __name__ == '__main__':
    main()